//package micycle.pgs;
//import java.awt.*;
//import java.awt.geom.Path2D;
//import java.awt.geom.PathIterator;
//import java.util.ArrayList;
//import java.util.List;
//import javax.swing.*;
//import static micycle.pgs.StraightSkeletonUtil.geometryToPath2D;
//import static micycle.pgs.StraightSkeletonUtil.path2DToPolygon;
//import org.locationtech.jts.geom.Coordinate;
//import org.locationtech.jts.geom.Geometry;
//
//public class SkeletonDemo extends JPanel {
//    private final Path2D inputPolygon;
//    private final List<Path2D> skeletonFaces;
//
//    public SkeletonDemo(Path2D inputPolygon, List<Path2D> skeletonFaces) {
//        this.inputPolygon = inputPolygon;
//        this.skeletonFaces = skeletonFaces;
//    }
//
//    @Override
//    protected void paintComponent(Graphics g) {
//        super.paintComponent(g);
//        Graphics2D g2d = (Graphics2D) g;
//
//        // Anti-aliasing for smoother rendering
//        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//
//        // Draw the original input polygon
//        g2d.setColor(Color.BLACK);
//        g2d.setStroke(new BasicStroke(2));
//        g2d.draw(inputPolygon);
//
//        // Draw skeleton faces
//        g2d.setColor(new Color(0, 0, 255, 128)); // Semi-transparent blue
//        g2d.setStroke(new BasicStroke(1));
//        for (Path2D skeletonFace : skeletonFaces) {
//            g2d.draw(skeletonFace);
//        }
//    }
//
//    public static void main(String[] args) {
//        // Create an example Path2D polygon (a simple house shape)
//        Path2D examplePolygon = new Path2D.Double();
//        examplePolygon.moveTo(100, 300); // Start at the bottom-left corner
//        examplePolygon.lineTo(200, 100); // Roof peak
//        examplePolygon.lineTo(300, 300); // Bottom-right corner
//        examplePolygon.closePath();     // Close the main shape
//
//        // Add a rectangular hole
//        examplePolygon.moveTo(150, 250);
//        examplePolygon.lineTo(150, 200);
//        examplePolygon.lineTo(250, 200);
//        examplePolygon.lineTo(250, 250);
//        examplePolygon.closePath();
//
//        // Use provided methods to compute the skeleton
//        List<Path2D> skeletonPaths = computeSkeletonPaths(examplePolygon);
//
//        // Create and display the GUI
//        JFrame frame = new JFrame("Skeleton Demo");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(600, 600);
//        frame.add(new SkeletonDemo(examplePolygon, skeletonPaths));
//        frame.setVisible(true);
//    }
//
///**
// * Computes skeleton paths from a Path2D polygon using the provided methods.
// *
// * @param inputPolygon the input Path2D polygon
// * @return a list of Path2D objects representing skeleton faces
// */
//private static List<Path2D> computeSkeletonPaths(Path2D inputPolygon) {
//    // Convert the input Path2D to a JTS Polygon
////    GeometryFactory factory = new GeometryFactory();
////    Coordinate[] coords = extractCoordinatesFromPath2D(inputPolygon);
////    Polygon jtsPolygon = factory.createPolygon(coords);
//
//    // Compute the skeleton faces using one of the provided methods
//    Geometry skeletonGeometry = StraightSkeletonUtil.createSkeletonFaces(path2DToPolygon(inputPolygon)); // Replace with straightSkeletonKendzi if needed
//
//    // Convert the JTS Geometry back into a list of Path2D using the provided converters
//    return geometryToPath2D(skeletonGeometry);
//}
//
//
//    /**
//     * Extracts coordinates from a Path2D object.
//     *
//     * @param path the Path2D object
//     * @return an array of Coordinate objects
//     */
//    private static Coordinate[] extractCoordinatesFromPath2D(Path2D path) {
//        List<Coordinate> coordinates = new ArrayList<>();
//        PathIterator iterator = path.getPathIterator(null);
//        double[] segment = new double[6];
//
//        while (!iterator.isDone()) {
//            int type = iterator.currentSegment(segment);
//            if (type == PathIterator.SEG_MOVETO || type == PathIterator.SEG_LINETO) {
//                coordinates.add(new Coordinate(segment[0], segment[1]));
//            } else if (type == PathIterator.SEG_CLOSE) {
//                // Close the path if required
//                coordinates.add(coordinates.get(0));
//            }
//            iterator.next();
//        }
//
//        return coordinates.toArray(new Coordinate[0]);
//    }
//    
//    
//}
