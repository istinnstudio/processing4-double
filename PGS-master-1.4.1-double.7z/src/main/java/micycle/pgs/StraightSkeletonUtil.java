package micycle.pgs;
import java.awt.geom.Path2D;
import java.awt.geom.PathIterator;
import java.util.*;
import java.util.stream.Collectors;
import kendzi.math.geometry.skeleton.SkeletonConfiguration;
import kendzi.math.geometry.skeleton.SkeletonOutput;
import micycle.pgs.PGS.LinearRingIterator;
import org.joml.Vector2d;
import org.joml.Vector2dc;
import org.locationtech.jts.algorithm.Orientation;
import org.locationtech.jts.geom.*;
import org.locationtech.jts.simplify.DouglasPeuckerSimplifier;
import org.twak.camp.Corner;
import org.twak.camp.Edge;
import org.twak.camp.Machine;
import org.twak.camp.Output;
import org.twak.camp.Skeleton;
import org.twak.utils.collections.Loop;
import org.twak.utils.collections.LoopL;

public class StraightSkeletonUtil {

    /**
     * Computes the straight skeleton for a shape using JTS.
     *
     * @param geometry A single polygon (with or without holes) or a multi-polygon.
     * @return A map with keys "faces", "branches", and "bones" containing respective geometries.
     */
    public static Map<String, Geometry> straightSkeleton(Geometry geometry) {
        if (geometry instanceof MultiPolygon) {
            return handleMultiPolygon((MultiPolygon) geometry);
        } else if (geometry instanceof Polygon) {
            return handlePolygon((Polygon) geometry);
        } else {
            throw new IllegalArgumentException("Unsupported geometry type: " + geometry.getGeometryType());
        }
    }

    private static Map<String, Geometry> handleMultiPolygon(MultiPolygon multiPolygon) {
        GeometryFactory factory = new GeometryFactory();
        List<Geometry> faceGeometries = new ArrayList<>();
        List<Geometry> branchGeometries = new ArrayList<>();
        List<Geometry> boneGeometries = new ArrayList<>();

        for (int i = 0; i < multiPolygon.getNumGeometries(); i++) {
            Map<String, Geometry> skeletonParts = handlePolygon((Polygon) multiPolygon.getGeometryN(i));
            faceGeometries.add(skeletonParts.get("faces"));
            branchGeometries.add(skeletonParts.get("branches"));
            boneGeometries.add(skeletonParts.get("bones"));
        }

        Map<String, Geometry> result = new HashMap<>();
        result.put("faces", factory.createGeometryCollection(faceGeometries.toArray(new Geometry[0])));
        result.put("branches", factory.createGeometryCollection(branchGeometries.toArray(new Geometry[0])));
        result.put("bones", factory.createGeometryCollection(boneGeometries.toArray(new Geometry[0])));

        return result;
    }

    private static Map<String, Geometry> handlePolygon(Polygon polygon) {
        if (polygon.getCoordinates().length > 1000) {
            polygon = (Polygon) DouglasPeuckerSimplifier.simplify(polygon, 2);
        }

        // Attempt Kendzi implementation first
        try {
            return computeStraightSkeletonKendzi(polygon);
        } catch (Exception e) {
            return computeStraightSkeletonTwakFallback(polygon);
        }
    }
    
       private static Map<String, Geometry> computeStraightSkeletonKendzi(Polygon polygon) {
        // Placeholder for Kendzi-based skeleton computation
        throw new UnsupportedOperationException("Kendzi implementation is not yet supported.");
    }

    private static Map<String, Geometry> computeStraightSkeletonTwakFallback(Polygon polygon) {
        GeometryFactory factory = new GeometryFactory();
        Set<Coordinate> edgeCoordsSet = new HashSet<>(Arrays.asList(polygon.getCoordinates()));

        // Placeholder logic for skeleton creation
        // For demonstration, we create empty collections.
        Geometry faces = factory.createGeometryCollection(null);
        
        
        faces = straightSkeletonTwak(polygon);
        
        
        Geometry branches = factory.createLineString(new Coordinate[0]);
        Geometry bones = factory.createLineString(new Coordinate[0]);

        Map<String, Geometry> result = new HashMap<>();
        result.put("faces", faces);
        result.put("branches", branches);
        result.put("bones", bones);

        return result;
    }
 
    // HEAP ERROR
    public static Geometry createSkeletonFacesZ0(Polygon polygon) {
    // Step 1: Simplify the polygon if it has too many vertices
    if (polygon.getCoordinates().length > 1000) {
        polygon = (Polygon) DouglasPeuckerSimplifier.simplify(polygon, 2);
    }

    // Step 2: Prepare the loop set and edge coordinate set
    Set<Coordinate> edgeCoordsSet = new HashSet<>();
    List<LinearRing> rings = new ArrayList<>();
    LinearRingIterator ringIterator = new LinearRingIterator(polygon);

    while (ringIterator.iterator().hasNext()) {
        rings.add(ringIterator.iterator().next());
    }

    // Step 3: Convert rings to loops and add to the list of loops
    LoopL<Edge> loops = new LoopL<>();
    Machine speed = new Machine(1); // constant speed for edges


    
    for (int i = 0; i < rings.size(); i++) {
        LinearRing ring = rings.get(i);
        loops.add(ringToLoop(ring, edgeCoordsSet, speed)); // Add to loops
    }

    // Step 4: Initialize the skeleton computation (this is a placeholder)
    Skeleton skeleton;
    try {
        skeleton = new Skeleton(loops, true);
        skeleton.skeleton(); // Compute skeleton
    } catch (Exception e) {
        System.err.println("Error computing skeleton: " + e.getMessage());
        return null;
    }

    // Step 5: Build the skeleton faces (represented as Polygons)
    List<Polygon> faces = new ArrayList<>();
    for (Output.Face face : skeleton.output.faces.values()) {
        List<Coordinate> faceCoords = new ArrayList<>();
        face.getLoopL().forEach(loop -> {
            loop.forEach(point -> faceCoords.add(new Coordinate(point.x, point.y)));
        });

        // Create a Polygon from the face coordinates (convert the face to a JTS Polygon)
        LinearRing faceRing = new GeometryFactory().createLinearRing(faceCoords.toArray(new Coordinate[0]));
        faces.add(new GeometryFactory().createPolygon(faceRing, null)); // No holes
    }

    // Step 6: Return the collection of skeleton faces as a GeometryCollection
    return new GeometryFactory().createGeometryCollection(faces.toArray(new Polygon[0]));
}


// experimental
public static Geometry createSkeletonFacesZ(Polygon polygon) {
    // Step 1: Simplify the polygon if it has too many vertices
    if (polygon.getCoordinates().length > 1000) {
        polygon = (Polygon) DouglasPeuckerSimplifier.simplify(polygon, 2);
    }

    // Step 2: Prepare the loop set and edge coordinate set
////    Set<Coordinate> edgeCoordsSet = new HashSet<>();
////    LinearRing[] rings = new LinearRing[polygon.getNumInteriorRing() + 1];
////    rings[0] = polygon.getExteriorRing();
////
////    for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
////        rings[i + 1] = polygon.getInteriorRingN(i);
////    }
////
////    
////    // Step 3: Convert rings to loops and add to the list of loops
////    LoopL<Edge> loops = new LoopL<>();
////    Machine speed = new Machine(1); // constant speed for edges
////
////    for (int i = 0; i < rings.length; i++) {
////        LinearRing ring = rings[i];
////        loops.add(ringToLoop(ring, edgeCoordsSet, speed)); // Add to loops
////    }


		final Set<Coordinate> edgeCoordsSet = new HashSet<>();
		final Skeleton skeleton;
		final LoopL<Edge> loops = new LoopL<>(); // list of loops
		final Machine speed = new Machine(1); // every edge same speed

		final LinearRing[] rings = new LinearRingIterator(polygon).getLinearRings();
		for (int i = 0; i < rings.length; i++) {
			loops.add(ringToLoop(rings[i], i > 0, edgeCoordsSet, speed));
		}
            
            
            
    // Step 4: Initialize the skeleton computation
//    Skeleton skeleton;
    try {
        skeleton = new Skeleton(loops, true);
        skeleton.skeleton(); // Compute skeleton
    } catch (OutOfMemoryError e) {
        System.err.println("Out of memory error while computing the skeleton.");
        return null;
    } catch (Exception e) {
        System.err.println("Error computing skeleton: " + e.getMessage());
        return null;
    }

    // Step 5: Build the skeleton faces (represented as Polygons)
    List<Polygon> faces = new ArrayList<>();
    for (Output.Face face : skeleton.output.faces.values()) {
        List<Coordinate> faceCoords = new ArrayList<>();
        
        face.getLoopL().forEach(loop -> {
            loop.forEach(point -> faceCoords.add(new Coordinate(point.x, point.y)));
        });

        // Create a LinearRing and Polygon from the face coordinates (convert the face to a JTS Polygon)
// Create a LinearRing and Polygon from the face coordinates (convert the face to a JTS Polygon)
if (!faceCoords.isEmpty() && !faceCoords.get(0).equals(faceCoords.get(faceCoords.size() - 1))) {
    faceCoords.add(faceCoords.get(0)); // Ensure the ring is closed
}

LinearRing faceRing = new GeometryFactory().createLinearRing(faceCoords.toArray(new Coordinate[0]));
faces.add(new GeometryFactory().createPolygon(faceRing, null)); // No holes
    }

    // Step 6: Return the collection of skeleton faces as a GeometryCollection
    return new GeometryFactory().createGeometryCollection(faces.toArray(new Polygon[0]));
}

	private static Loop<Edge> ringToLoop(LinearRing ring, boolean hole, Set<Coordinate> edgeCoordsSet, Machine speed) {
		Coordinate[] coords = ring.getCoordinates();
		if (!hole && !Orientation.isCCW(coords)) {
			reverse(coords); // exterior should be CCW
		}
		if (hole && Orientation.isCCW(coords)) {
			reverse(coords); // holes should be CW
		}

		List<Corner> corners = new ArrayList<>();
		Loop<Edge> loop = new Loop<>();

		for (int j = 0; j < coords.length; j++) {
			corners.add(new Corner(coords[j].x, coords[j].y));
			edgeCoordsSet.add(coords[j]);
		}

		for (int j = 0; j < corners.size() - 1; j++) {
			Edge edge = new Edge(corners.get(j), corners.get((j + 1) % (corners.size() - 1)));
			edge.machine = speed;
			loop.append(edge);
		}

		return loop;
	}
   
      	private static <T> void reverse(T[] a) {
		// used in straightSkeleton()
		int l = a.length;
		for (int j = 0; j < l / 2; j++) {
			T temp = a[j];
			a[j] = a[l - j - 1];
			a[l - j - 1] = temp;
		}
	}
            
        public static  Geometry createSkeletonFaces(Polygon polygon) {
        if (polygon.getCoordinates().length > 1000) {
            polygon = (Polygon) DouglasPeuckerSimplifier.simplify(polygon, 2);
        }

        // Attempt Kendzi implementation first
        try {
            return straightSkeletonKendzi(polygon);
        } catch (Exception e) {
            return straightSkeletonTwak(polygon);
        }
    }
        
     /**
 * Creates the skeleton faces from a Path2D object representing a polygon
 * that can contain holes. It first attempts the Kendzi method and falls
 * back to the Twak method if an exception is thrown.
 *
 * @param path a Path2D object representing a polygon that can contain holes
 * @return a GeometryCollection of Polygon objects representing the skeleton faces
 */
public static Geometry createSkeletonFaces(Path2D path) {
    // Step 1: Convert Path2D to JTS Polygon
    Polygon polygon = path2DToPolygon(path);

    // Simplify large polygons if necessary
    if (polygon.getCoordinates().length > 1000) {
        polygon = (Polygon) DouglasPeuckerSimplifier.simplify(polygon, 2);
    }

    // Step 2: Attempt Kendzi implementation first
    try {
        return straightSkeletonKendzi(polygon);
    } catch (Exception e) {
        // If Kendzi fails, fall back to the Twak implementation
        return straightSkeletonTwak(polygon);
    }
}   

public static Geometry createSkeletonFaces2(Path2D path) {
    // Step 1: Convert Path2D to JTS Polygon
    Polygon polygon = path2DToPolygon(path);

    // Simplify large polygons if necessary
//    if (polygon.getCoordinates().length > 1000) {
//        polygon = (Polygon) DouglasPeuckerSimplifier.simplify(polygon, 2);
//    }

    // Step 2: Attempt Kendzi implementation first
    try {
        return straightSkeletonKendzi(path);
    } catch (Exception e) {
        // If Kendzi fails, fall back to the Twak implementation
        return straightSkeletonTwak(path);
    }
}   


    // Helper method to convert JTS LinearRing to a list of coordinates
    private static List<Coordinate> linearRingToCoordinates(LinearRing ring) {
        return Arrays.stream(ring.getCoordinates()).collect(Collectors.toList());
    }

    // Helper method to create a loop structure for skeleton computation (for fallback)
    private static List<Coordinate[]> createLoops(Polygon polygon) {
        List<Coordinate[]> loops = new ArrayList<>();
        loops.add(polygon.getExteriorRing().getCoordinates());
        for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
            loops.add(polygon.getInteriorRingN(i).getCoordinates());
        }
        return loops;
    }
/**
 * Computes the straight skeleton using Twak's method.
 *
 * @param polygon a single JTS Polygon that can contain holes
 * @return a GeometryCollection of Polygon objects representing the skeleton faces
 */
private static Geometry straightSkeletonTwak(Polygon polygon) {
    GeometryFactory factory = new GeometryFactory();

    // Simplify large polygons
    if (polygon.getCoordinates().length > 1000) {
        polygon = (Polygon) DouglasPeuckerSimplifier.simplify(polygon, 1);
    }

    // Validate and clean the polygon
    if (!polygon.isValid()) {
        polygon = (Polygon) polygon.buffer(0); // Fix invalid geometries
    }

    // Ensure all rings are closed and valid
    LinearRing shell = factory.createLinearRing(
        removeDuplicateCoordinates(polygon.getExteriorRing().getCoordinates())
    );

    if (!shell.isValid()) {
        throw new IllegalArgumentException("Exterior ring is invalid");
    }

    LoopL<Edge> loops = new LoopL<>();
    Machine speed = new Machine(1); // Constant speed for edges
    Set<Coordinate> edgeCoordsSet = new HashSet<>();
    loops.add(ringToLoop(shell, edgeCoordsSet, speed));

    for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
        LinearRing hole = factory.createLinearRing(
            removeDuplicateCoordinates(polygon.getInteriorRingN(i).getCoordinates())
        );

        if (!hole.isValid()) {
            throw new IllegalArgumentException("Interior ring is invalid");
        }

        loops.add(ringToLoop(hole, edgeCoordsSet, speed));
    }

    List<List<Coordinate>> faceCoordinates = new ArrayList<>();
    try {
        Skeleton skeleton = new Skeleton(loops, true);
        skeleton.skeleton();

        skeleton.output.faces.values().forEach(face -> {
            List<Coordinate> faceVertices = new ArrayList<>();
            face.getLoopL().forEach(loop -> {
                loop.forEach(point -> faceVertices.add(new Coordinate(point.x, point.y)));
            });
            faceCoordinates.add(faceVertices);
        });
    } catch (IllegalArgumentException e) {
        System.err.println("Error in input geometry: " + e.getMessage());
        return null;
    } catch (Exception e) {
        System.err.println("Unexpected error during skeleton computation: " + e.getMessage());
        return null;
    }

    List<Polygon> skeletonFaces = new ArrayList<>();
    for (List<Coordinate> face : faceCoordinates) {
        if (face.size() > 2) {
            LinearRing ring = factory.createLinearRing(face.toArray(new Coordinate[0]));
            skeletonFaces.add(factory.createPolygon(ring, null));
        }
    }

    return factory.createGeometryCollection(skeletonFaces.toArray(new Polygon[0]));
}

/**
 * Computes the straight skeleton using Twak's method.
 *
 * @param path a Path2D object representing a polygon that can contain holes
 * @return a GeometryCollection of Polygon objects representing the skeleton faces
 */
private static Geometry straightSkeletonTwak(Path2D path) {
    // Step 1: Convert Path2D to JTS Polygon
    Polygon polygon = path2DToPolygon(path);

    GeometryFactory factory = new GeometryFactory();

    // Simplify large polygons
    if (polygon.getCoordinates().length > 1000) {
        polygon = (Polygon) DouglasPeuckerSimplifier.simplify(polygon, 1);
    }

    // Validate and clean the polygon
    if (!polygon.isValid()) {
        polygon = (Polygon) polygon.buffer(0); // Fix invalid geometries
    }

    // Ensure all rings are closed and valid
    LinearRing shell = factory.createLinearRing(
        removeDuplicateCoordinates(polygon.getExteriorRing().getCoordinates())
    );

    if (!shell.isValid()) {
        throw new IllegalArgumentException("Exterior ring is invalid");
    }

    LoopL<Edge> loops = new LoopL<>();
    Machine speed = new Machine(1); // Constant speed for edges
    Set<Coordinate> edgeCoordsSet = new HashSet<>();
    loops.add(ringToLoop(shell, edgeCoordsSet, speed));

    // Handle interior rings (holes)
    for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
        LinearRing hole = factory.createLinearRing(
            removeDuplicateCoordinates(polygon.getInteriorRingN(i).getCoordinates())
        );

        if (!hole.isValid()) {
            throw new IllegalArgumentException("Interior ring is invalid");
        }

        loops.add(ringToLoop(hole, edgeCoordsSet, speed));
    }

    // Step 3: Compute the skeleton faces
    List<List<Coordinate>> faceCoordinates = new ArrayList<>();
    try {
        Skeleton skeleton = new Skeleton(loops, true);
        skeleton.skeleton();

        skeleton.output.faces.values().forEach(face -> {
            List<Coordinate> faceVertices = new ArrayList<>();
            face.getLoopL().forEach(loop -> {
                loop.forEach(point -> faceVertices.add(new Coordinate(point.x, point.y)));
            });
            faceCoordinates.add(faceVertices);
        });
    } catch (IllegalArgumentException e) {
        System.err.println("Error in input geometry: " + e.getMessage());
        return null;
    } catch (Exception e) {
        System.err.println("Unexpected error during skeleton computation: " + e.getMessage());
        return null;
    }

    // Step 4: Create and return the skeleton faces as Polygons
    List<Polygon> skeletonFaces = new ArrayList<>();
    for (List<Coordinate> face : faceCoordinates) {
        if (face.size() > 2) {
            LinearRing ring = factory.createLinearRing(face.toArray(new Coordinate[0]));
            skeletonFaces.add(factory.createPolygon(ring, null));
        }
    }

    return factory.createGeometryCollection(skeletonFaces.toArray(new Polygon[0]));
}




private static Coordinate[] removeDuplicateCoordinates(Coordinate[] coordinates) {
    if (coordinates == null || coordinates.length < 2) {
        return coordinates; // Nothing to process
    }

    List<Coordinate> uniqueCoords = new ArrayList<>();
    Coordinate previous = null;

    for (Coordinate current : coordinates) {
        if (previous == null || !current.equals2D(previous)) {
            uniqueCoords.add(current); // Add if not a duplicate
        }
        previous = current;
    }

    // Ensure the ring is closed, if required
    if (!uniqueCoords.isEmpty() && !uniqueCoords.get(0).equals2D(uniqueCoords.get(uniqueCoords.size() - 1))) {
        uniqueCoords.add(uniqueCoords.get(0)); // Close the ring
    }

    return uniqueCoords.toArray(new Coordinate[0]);
}

/**
 * Computes the straight skeleton using Kendzi's method.
 *
 * @param polygon a single JTS Polygon that can contain holes
 * @return a GeometryCollection of Polygon objects representing the skeleton faces
 */
private static Geometry straightSkeletonKendzi(Polygon polygon) {
    // Extract the exterior ring as Vector2dc
    LinearRing shell = (LinearRing) polygon.getExteriorRing();
    List<Vector2dc> shellCoords = Arrays.stream(shell.getCoordinates())
            .map(coord -> new Vector2d(coord.x, coord.y))
            .collect(Collectors.toList());

    // Extract the interior rings (holes) as Vector2dc
    List<List<Vector2dc>> holes = new ArrayList<>();
    for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
        LinearRing hole = (LinearRing) polygon.getInteriorRingN(i);
        holes.add(Arrays.stream(hole.getCoordinates())
                .map(coord -> new Vector2d(coord.x, coord.y))
                .collect(Collectors.toList()));
    }

    // Compute the straight skeleton using Kendzi's method
    SkeletonOutput skeletonOutput = kendzi.math.geometry.skeleton.Skeleton.skeleton(
            shellCoords,
            holes,
            new SkeletonConfiguration()
    );

    List<List<Coordinate>> faceCoordinates = new ArrayList<>();
    GeometryFactory factory = new GeometryFactory();

    // Extract skeleton faces
    skeletonOutput.getFaces().forEach(face -> {
        List<Coordinate> faceVertices = new ArrayList<>();
        face.getPoints().forEach(point -> {
            faceVertices.add(new Coordinate(point.x(), point.y()));
        });
        faceCoordinates.add(faceVertices);
    });

    // Convert face coordinates into JTS Polygons
    List<Polygon> skeletonFaces = new ArrayList<>();
    faceCoordinates.forEach(face -> {
        LinearRing ring = factory.createLinearRing(face.toArray(new Coordinate[0]));
        skeletonFaces.add(factory.createPolygon(ring, null));
    });

    return factory.createGeometryCollection(skeletonFaces.toArray(new Polygon[0]));
}

/**
 * Computes the straight skeleton using Kendzi's method.
 *
 * @param path a Path2D object representing a polygon that can contain holes
 * @return a GeometryCollection of Polygon objects representing the skeleton faces
 */
private static Geometry straightSkeletonKendzi(Path2D path) {
    // Step 1: Convert Path2D to JTS Polygon
    Polygon polygon = path2DToPolygon(path);

    // Extract the exterior ring as Vector2dc
    LinearRing shell = (LinearRing) polygon.getExteriorRing();
    List<Vector2dc> shellCoords = Arrays.stream(shell.getCoordinates())
            .map(coord -> new Vector2d(coord.x, coord.y))
            .collect(Collectors.toList());

    // Extract the interior rings (holes) as Vector2dc
    List<List<Vector2dc>> holes = new ArrayList<>();
    for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
        LinearRing hole = (LinearRing) polygon.getInteriorRingN(i);
        holes.add(Arrays.stream(hole.getCoordinates())
                .map(coord -> new Vector2d(coord.x, coord.y))
                .collect(Collectors.toList()));
    }

    // Step 2: Compute the straight skeleton using Kendzi's method
    SkeletonOutput skeletonOutput = kendzi.math.geometry.skeleton.Skeleton.skeleton(
            shellCoords,
            holes,
            new SkeletonConfiguration()
    );

    // Step 3: Extract skeleton faces
    List<List<Coordinate>> faceCoordinates = new ArrayList<>();
    GeometryFactory factory = new GeometryFactory();

    skeletonOutput.getFaces().forEach(face -> {
        List<Coordinate> faceVertices = new ArrayList<>();
        face.getPoints().forEach(point -> {
            faceVertices.add(new Coordinate(point.x(), point.y()));
        });
        faceCoordinates.add(faceVertices);
    });

    // Step 4: Convert face coordinates into JTS Polygons
    List<Polygon> skeletonFaces = new ArrayList<>();
    faceCoordinates.forEach(face -> {
        LinearRing ring = factory.createLinearRing(face.toArray(new Coordinate[0]));
        skeletonFaces.add(factory.createPolygon(ring, null));
    });

    // Return the GeometryCollection of skeleton faces
    return factory.createGeometryCollection(skeletonFaces.toArray(new Polygon[0]));
}


/**
 * Helper method to convert a LinearRing into a Loop of Edges.
 *
 * @param ring          the LinearRing to convert
 * @param edgeCoordsSet set to store unique coordinates
 * @param speed         speed for the edges
 * @return a Loop of Edges
 */
private static Loop<Edge> ringToLoop(LinearRing ring, Set<Coordinate> edgeCoordsSet, Machine speed) {
    Loop<Edge> loop = new Loop<>();
    Coordinate[] coords = ring.getCoordinates();
    for (int i = 0; i < coords.length - 1; i++) {
        Coordinate c1 = coords[i];
        Coordinate c2 = coords[i + 1];
        edgeCoordsSet.add(c1);

        // Create Corner objects for start and end points
        Corner start = new Corner(c1.x, c1.y);
        Corner end = new Corner(c2.x, c2.y);

        // Create the Edge object with angle = 0 (default, if no specific angle is provided)
        Edge edge = new Edge(start, end, 0.0);

        loop.append(edge);
    }
    return loop;
}

/**
 * Converts a JTS Geometry into a list of Path2D objects.
 * Supports holes in polygons and multiple faces in Geometry.
 *
 * @param geometry the input JTS Geometry to convert
 * @return a list of Path2D objects representing the geometry
 */
public static List<Path2D> geometryToPath2D(Geometry geometry) {
    List<Path2D> paths = new ArrayList<>();

    if (geometry instanceof GeometryCollection) {
        GeometryCollection collection = (GeometryCollection) geometry;
        for (int i = 0; i < collection.getNumGeometries(); i++) {
            Geometry geom = collection.getGeometryN(i);
            paths.addAll(convertSingleGeometryToPath2D(geom));
        }
    } else {
        paths.addAll(convertSingleGeometryToPath2D(geometry));
    }

    return paths;
}

/**
 * Converts a single JTS Geometry (Polygon or MultiPolygon) into a single Path2D object
 * with multiple subpaths.
 *
 * @param geometry the single geometry to convert
 * @return a single Path2D object with subpaths for each polygon and its holes
 */
private static Path2D convertSingleGeometryToSinglePath2D(Geometry geometry) {
    Path2D path = new Path2D.Double();

    if (geometry instanceof Polygon) {
        appendPolygonToPath((Polygon) geometry, path);
    } else if (geometry instanceof MultiPolygon) {
        MultiPolygon multiPolygon = (MultiPolygon) geometry;
        for (int i = 0; i < multiPolygon.getNumGeometries(); i++) {
            Geometry geom = multiPolygon.getGeometryN(i);
            if (geom instanceof Polygon) {
                appendPolygonToPath((Polygon) geom, path);
            }
        }
    }

    return path;
}

/**
 * Appends a JTS Polygon (with its holes) to a Path2D object.
 *
 * @param polygon the polygon to append
 * @param path    the Path2D to modify
 */
private static void appendPolygonToPath(Polygon polygon, Path2D path) {
    // Append the exterior ring
    Coordinate[] exteriorCoords = polygon.getExteriorRing().getCoordinates();
    appendRingToPath(exteriorCoords, path);

    // Append each interior ring (hole)
    for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
        Coordinate[] holeCoords = polygon.getInteriorRingN(i).getCoordinates();
        appendRingToPath(holeCoords, path);
    }
}

/**
 * Appends a ring (either exterior or interior) as a subpath to a Path2D.
 *
 * @param coords the coordinates of the ring
 * @param path   the Path2D to modify
 */
private static void appendRingToPath(Coordinate[] coords, Path2D path) {
    if (coords.length < 2) {
       return;
    }

    // Move to the starting point of the ring
    path.moveTo(coords[0].x, coords[0].y);

    // Draw lines to the subsequent points
    for (int i = 1; i < coords.length; i++) {
        path.lineTo(coords[i].x, coords[i].y);
    }

    // Close the ring
    path.closePath();
}


/**
 * Converts a single JTS Geometry (Polygon or MultiPolygon) into Path2D objects.
 *
 * @param geometry the single geometry to convert
 * @return a list of Path2D objects
 */
private static List<Path2D> convertSingleGeometryToPath2D(Geometry geometry) {
    List<Path2D> paths = new ArrayList<>();

    if (geometry instanceof Polygon) {
        paths.add(convertPolygonToPath2D((Polygon) geometry));
    } else if (geometry instanceof MultiPolygon) {
        MultiPolygon multiPolygon = (MultiPolygon) geometry;
        for (int i = 0; i < multiPolygon.getNumGeometries(); i++) {
            Geometry geom = multiPolygon.getGeometryN(i);
            if (geom instanceof Polygon) {
                paths.add(convertPolygonToPath2D((Polygon) geom));
            }
        }
    }

    return paths;
}

/**
 * Converts a single JTS Geometry (Polygon or MultiPolygon) into a Path2D object.
 *
 * @param geometry the single geometry to convert
 * @return a Path2D object representing the geometry
 */
public static Path2D convertSingleGeometryToPath2DAppend(Geometry geometry) {
    Path2D path = new Path2D.Double();  // Create a single Path2D to append to

    if (geometry instanceof Polygon) {
        path.append(convertPolygonToPath2D((Polygon) geometry), false);
    } else if (geometry instanceof MultiPolygon) {
        MultiPolygon multiPolygon = (MultiPolygon) geometry;
        for (int i = 0; i < multiPolygon.getNumGeometries(); i++) {
            Geometry geom = multiPolygon.getGeometryN(i);
            if (geom instanceof Polygon) {
                path.append(convertPolygonToPath2D((Polygon) geom), false);
            }
        }
    }

    return path;
}


/**
 * Converts a JTS Polygon into a Path2D object, including holes.
 *
 * @param polygon the polygon to convert
 * @return a Path2D object representing the polygon with holes
 */
private static Path2D convertPolygonToPath2D(Polygon polygon) {
    Path2D path = new Path2D.Double();

    // Convert the exterior ring
    Coordinate[] exteriorCoords = polygon.getExteriorRing().getCoordinates();
    addRingToPath(path, exteriorCoords, false);

    // Convert each interior ring (hole)
    for (int i = 0; i < polygon.getNumInteriorRing(); i++) {
        Coordinate[] holeCoords = polygon.getInteriorRingN(i).getCoordinates();
        addRingToPath(path, holeCoords, true);
    }

    return path;
}

/**
 * Adds a ring (either exterior or interior) to a Path2D.
 *
 * @param path     the Path2D to modify
 * @param coords   the coordinates of the ring
 * @param isHole   true if the ring is a hole
 */
private static void addRingToPath(Path2D path, Coordinate[] coords, boolean isHole) {
    if (coords.length < 2) {
       return;
    }

    if (isHole) {
        path.moveTo(coords[0].x, coords[0].y); // Start new sub-path for the hole
    } else {
        path.moveTo(coords[0].x, coords[0].y); // Start the main path
    }

    for (int i = 1; i < coords.length; i++) {
        path.lineTo(coords[i].x, coords[i].y);
    }

    path.closePath(); // Close the ring
}


/**
 * Converts a Path2D object into a JTS Geometry.
 * Supports subpaths, including exterior rings and holes.
 *
 * @param path the Path2D to convert
 * @return a JTS Geometry representing the Path2D
 */
public static Geometry path2DToGeometry(Path2D path) {
    List<LinearRing> exteriorRings = new ArrayList<>();
    List<LinearRing> holeRings = new ArrayList<>();

    GeometryFactory geometryFactory = new GeometryFactory();

    // Iterate over the Path2D segments
    PathIterator iterator = path.getPathIterator(null);
    List<Coordinate> currentRing = new ArrayList<>();
    boolean isHole = false;

    while (!iterator.isDone()) {
        double[] coords = new double[6];
        int type = iterator.currentSegment(coords);

        switch (type) {
            case PathIterator.SEG_MOVETO:
                // Start a new ring
                if (!currentRing.isEmpty()) {
                    // Add the completed ring to the appropriate list
                    addRingToLists(currentRing, isHole, exteriorRings, holeRings, geometryFactory);
                }
                currentRing = new ArrayList<>();
                currentRing.add(new Coordinate(coords[0], coords[1]));
                isHole = false; // Reset the hole flag for the new ring
                break;

            case PathIterator.SEG_LINETO:
                currentRing.add(new Coordinate(coords[0], coords[1]));
                break;

            case PathIterator.SEG_CLOSE:
                // Close the current ring
                if (!currentRing.isEmpty()) {
                    currentRing.add(currentRing.get(0)); // Ensure the ring is closed
                    addRingToLists(currentRing, isHole, exteriorRings, holeRings, geometryFactory);
                    currentRing = new ArrayList<>();
                }
                break;
        }

        iterator.next();
    }

    // Add any remaining ring
    if (!currentRing.isEmpty()) {
        addRingToLists(currentRing, isHole, exteriorRings, holeRings, geometryFactory);
    }

    // Build Polygons from exterior rings and their associated holes
    List<Polygon> polygons = new ArrayList<>();
    for (LinearRing exterior : exteriorRings) {
        List<LinearRing> associatedHoles = new ArrayList<>();
        for (LinearRing hole : holeRings) {
            if (isHoleInsideExterior(hole, exterior)) {
                associatedHoles.add(hole);
            }
        }
        Polygon polygon = geometryFactory.createPolygon(exterior, associatedHoles.toArray(new LinearRing[0]));
        polygons.add(polygon);
    }

    // Return a MultiPolygon if there are multiple disconnected polygons
    if (polygons.size() > 1) {
        return geometryFactory.createMultiPolygon(polygons.toArray(new Polygon[0]));
    } else {
        return polygons.get(0);
    }
}

/**
 * Adds a completed ring to the appropriate list based on its type.
 *
 * @param ring          the list of coordinates forming the ring
 * @param isHole        true if the ring is a hole
 * @param exteriorRings the list of exterior rings
 * @param holeRings     the list of hole rings
 * @param factory       the GeometryFactory for creating LinearRings
 */
private static void addRingToLists(List<Coordinate> ring, boolean isHole,
                                   List<LinearRing> exteriorRings, List<LinearRing> holeRings,
                                   GeometryFactory factory) {
    if (ring.size() < 4) {
        return; // A valid ring must have at least 4 points (3 unique + 1 closing)
    }

    LinearRing linearRing = factory.createLinearRing(ring.toArray(new Coordinate[0]));
    if (isHole) {
        holeRings.add(linearRing);
    } else {
        exteriorRings.add(linearRing);
    }
}

/**
 * Checks if a hole (LinearRing) is inside an exterior ring.
 *
 * @param hole     the hole to check
 * @param exterior the exterior ring
 * @return true if the hole is inside the exterior
 */
private static boolean isHoleInsideExterior(LinearRing hole, LinearRing exterior) {
    GeometryFactory factory = new GeometryFactory();
    Polygon exteriorPolygon = factory.createPolygon(exterior);
    return exteriorPolygon.contains(hole);
}

/**
 * Extracts the starting and ending coordinates from a Path2D subpath to determine hole/exterior.
 * A heuristic can be added to determine hole status based on winding order or area.
 */
private static boolean isHoleHeuristic(List<Coordinate> coords) {
    // Example heuristic: use area sign to determine orientation (clockwise or counter-clockwise)
    return computeSignedArea(coords) < 0;
}

/**
 * Computes the signed area of a ring.
 *
 * @param coords the list of coordinates
 * @return the signed area; negative indicates a clockwise ring
 */
private static double computeSignedArea(List<Coordinate> coords) {
    double area = 0;
    for (int i = 0; i < coords.size() - 1; i++) {
        Coordinate c1 = coords.get(i);
        Coordinate c2 = coords.get(i + 1);
        area += (c1.x * c2.y - c2.x * c1.y);
    }
    return area / 2.0;
}
public static Polygon path2DToPolygon(Path2D path) {
    GeometryFactory geometryFactory = new GeometryFactory();

    PathIterator iterator = path.getPathIterator(null);
    List<List<Coordinate>> rings = new ArrayList<>(); // List of rings (outer + holes)
    List<Coordinate> currentRing = new ArrayList<>();

    while (!iterator.isDone()) {
        double[] coords = new double[6];
        int type = iterator.currentSegment(coords);

        switch (type) {
            case PathIterator.SEG_MOVETO:
                // Start a new ring, save the previous one if it exists
                if (!currentRing.isEmpty()) {
                    if (currentRing.size() > 1) {  // Avoid adding empty or single-point rings
                        rings.add(new ArrayList<>(currentRing));
                    }
                    currentRing.clear();
                }
                currentRing.add(new Coordinate(coords[0], coords[1]));
                break;

            case PathIterator.SEG_LINETO:
                currentRing.add(new Coordinate(coords[0], coords[1]));
                break;

            case PathIterator.SEG_CLOSE:
                // Close the current ring
                if (!currentRing.isEmpty() && currentRing.size() > 1) {
                    currentRing.add(currentRing.get(0)); // Ensure the ring is closed
                    rings.add(new ArrayList<>(currentRing));
                    currentRing.clear();
                }
                break;
        }

        iterator.next();
    }

    // Add the last ring if necessary
    if (!currentRing.isEmpty() && currentRing.size() > 1) {
        currentRing.add(currentRing.get(0)); // Ensure the ring is closed
        rings.add(currentRing);
    }

    if (rings.isEmpty()) {
        throw new IllegalArgumentException("Path2D does not contain valid rings to create a Polygon");
    }

    // Convert the first ring to the exterior ring
    LinearRing exteriorRing = geometryFactory.createLinearRing(
        rings.get(0).toArray(new Coordinate[0])
    );

    // Convert subsequent rings to interior rings (holes)
    LinearRing[] holes = new LinearRing[rings.size() - 1];
    for (int i = 1; i < rings.size(); i++) {
        holes[i - 1] = geometryFactory.createLinearRing(
            rings.get(i).toArray(new Coordinate[0])
        );
    }

    // Create the Polygon
    Polygon polygon = geometryFactory.createPolygon(exteriorRing, holes);

    // Check if the created Polygon is valid
    if (!polygon.isValid()) {
        throw new IllegalArgumentException("The created polygon is invalid (e.g., self-intersecting or degenerate).");
    }

    return polygon;
}

public static Polygon path2DToPolygon2(Path2D path) {
    GeometryFactory geometryFactory = new GeometryFactory();

    PathIterator iterator = path.getPathIterator(null);
    List<List<Coordinate>> rings = new ArrayList<>(); // List of rings (outer + holes)
    List<Coordinate> currentRing = new ArrayList<>();
    boolean isFirstSubpath = true;  // To track the first subpath (exterior ring)

    while (!iterator.isDone()) {
        double[] coords = new double[6];
        int type = iterator.currentSegment(coords);

        switch (type) {
            case PathIterator.SEG_MOVETO:
                // Save the current ring if it's not empty and add to rings
                if (!currentRing.isEmpty()) {
                    if (currentRing.size() > 1) {  // Avoid adding empty or single-point rings
                        rings.add(new ArrayList<>(currentRing));
                    }
                    currentRing.clear();
                }
                currentRing.add(new Coordinate(coords[0], coords[1]));
                break;

            case PathIterator.SEG_LINETO:
                currentRing.add(new Coordinate(coords[0], coords[1]));
                break;

            case PathIterator.SEG_CLOSE:
                // Close the current ring and add it to the list of rings
                if (!currentRing.isEmpty() && currentRing.size() > 1) {
                    currentRing.add(currentRing.get(0)); // Ensure the ring is closed
                    rings.add(new ArrayList<>(currentRing));
                    currentRing.clear();
                }
                break;
        }

        iterator.next();
    }

    // Add the last ring if necessary
    if (!currentRing.isEmpty() && currentRing.size() > 1) {
        currentRing.add(currentRing.get(0)); // Ensure the ring is closed
        rings.add(currentRing);
    }

    if (rings.isEmpty()) {
        throw new IllegalArgumentException("Path2D does not contain valid rings to create a Polygon");
    }

    // Convert the first ring to the exterior ring (main polygon)
    LinearRing exteriorRing = geometryFactory.createLinearRing(
        rings.get(0).toArray(new Coordinate[0])
    );

    // Convert subsequent rings to interior rings (holes)
    LinearRing[] holes = new LinearRing[rings.size() - 1];
    for (int i = 1; i < rings.size(); i++) {
        holes[i - 1] = geometryFactory.createLinearRing(
            rings.get(i).toArray(new Coordinate[0])
        );
    }

    // Create and return the Polygon with the exterior and holes
    return geometryFactory.createPolygon(exteriorRing, holes);
}




public static List<Polygon> path2DToPolygonsExtra(Path2D path) {
    GeometryFactory geometryFactory = new GeometryFactory();

    PathIterator iterator = path.getPathIterator(null);
    List<List<Coordinate>> rings = new ArrayList<>(); // List of rings (outer + holes)
    List<Coordinate> currentRing = new ArrayList<>();
    List<Polygon> polygons = new ArrayList<>();

    boolean isFirstSubpath = true;  // To track the first subpath

    while (!iterator.isDone()) {
        double[] coords = new double[6];
        int type = iterator.currentSegment(coords);

        switch (type) {
            case PathIterator.SEG_MOVETO:
                // Save the current ring if it's not empty and add to polygons
                if (!currentRing.isEmpty()) {
                    if (currentRing.size() > 1) {  // Avoid adding empty or single-point rings
                        rings.add(new ArrayList<>(currentRing));
                    }
                    currentRing.clear();
                }
                currentRing.add(new Coordinate(coords[0], coords[1]));
                break;

            case PathIterator.SEG_LINETO:
                currentRing.add(new Coordinate(coords[0], coords[1]));
                break;

            case PathIterator.SEG_CLOSE:
                // Close the current ring and add it to the list of rings
                if (!currentRing.isEmpty() && currentRing.size() > 1) {
                    currentRing.add(currentRing.get(0)); // Ensure the ring is closed
                    rings.add(new ArrayList<>(currentRing));
                    currentRing.clear();
                }
                break;
        }

        iterator.next();
    }

    // Add the last ring if necessary
    if (!currentRing.isEmpty() && currentRing.size() > 1) {
        currentRing.add(currentRing.get(0)); // Ensure the ring is closed
        rings.add(currentRing);
    }

    if (rings.isEmpty()) {
        throw new IllegalArgumentException("Path2D does not contain valid rings to create a Polygon");
    }

    // Loop through rings and handle exterior + interior rings (holes)
    for (int i = 0; i < rings.size(); i++) {
        LinearRing exteriorRing = geometryFactory.createLinearRing(
            rings.get(i).toArray(new Coordinate[0])
        );
        
        LinearRing[] holes = new LinearRing[0];
        if (!isFirstSubpath) {
            holes = new LinearRing[1];  // Treat subsequent subpaths as holes
            holes[0] = geometryFactory.createLinearRing(
                rings.get(i).toArray(new Coordinate[0])
            );
        }
        
        // Create the Polygon
        Polygon polygon = geometryFactory.createPolygon(exteriorRing, holes);
        
        // Add the polygon to the list
        polygons.add(polygon);
        
        isFirstSubpath = false;  // After first subpath, treat subsequent ones as holes
    }

    return polygons;  // Return a list of polygons (handles subpaths separately)
}



}