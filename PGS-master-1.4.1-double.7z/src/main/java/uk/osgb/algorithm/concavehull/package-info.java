/*
 * This library provides methods to construct concave hull of a collection of JTS Coordinates or Geometry.
 * It supports construction under different criteria, hull with multiple parts as well as hull with holes.
 */
package uk.osgb.algorithm.concavehull;