package processing.core;


public class PSketch implements PConstants {
    // this is a dummy class
}