/**
 * https://github.com/skipperkongen/jts-algorithm-pack
 */
package org.geodelivery.jap.concavehull;