/**
 * The commons package contains all non-core PGS classes (of varying authorship
 * and either not worth putting in separate package or too long to include
 * within the calling PGS method itself).
 */
package micycle.pgs.commons;